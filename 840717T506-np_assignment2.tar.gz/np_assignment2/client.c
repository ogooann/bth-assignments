#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <signal.h>
#include <netdb.h>
#include <errno.h>

const char* SERVER_IP = "13.53.76.30";
const int SERVER_PORT = 5000;
const int MAX_RETRIES = 2;
const int TIMEOUT_SECONDS = 2;
const char* DEBUG_FLAG = "-d";

#define DEBUG_ENABLED 0

#if DEBUG_ENABLED
#define DEBUG_PRINT(msg) printf("%s\n", msg)
#else
#define DEBUG_PRINT(msg)
#endif

struct calcMessage {
    uint16_t type;
    uint32_t message;
    uint16_t protocol;
    uint16_t major_version;
    uint16_t minor_version;
};

struct calcProtocol {
    uint16_t type;
    uint16_t major_version;
    uint16_t minor_version;
    uint32_t id;
    uint32_t arith;
    int32_t inValue1;
    int32_t inValue2;
    int32_t inResult;
    double flValue1;
    double flValue2;
    double flResult;
};

void timeoutHandler(int signum) {
    printf("Timeout: Server did not reply.\n");
    exit(1);
}

int main(int argc, char* argv[]) {
    bool debugEnabled = false;
    if (argc > 1 && strcmp(argv[1], DEBUG_FLAG) == 0) {
        debugEnabled = true;
    }

    signal(SIGALRM, timeoutHandler);

    int clientSocket = socket(AF_INET, SOCK_DGRAM, 0);
    if (clientSocket == -1) {
        perror("Error creating socket");
        return 1;
    }

    struct sockaddr_in serverAddr;
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(SERVER_PORT);

    struct hostent* host = gethostbyname(SERVER_IP);
    if (host != NULL) {
        struct in_addr** addressList = (struct in_addr**)host->h_addr_list;
        if (addressList[0] != NULL) {
            SERVER_IP = inet_ntoa(*addressList[0]);
        }
    }

    if (inet_pton(AF_INET, SERVER_IP, &serverAddr.sin_addr) != 1) {
        perror("Error converting server IP address");
        close(clientSocket);
        return 1;
    }

    struct calcMessage request;
    request.type = htons(22);
    request.message = htonl(0);
    request.protocol = htons(17);
    request.major_version = htons(1);
    request.minor_version = htons(0);

    alarm(TIMEOUT_SECONDS);

    int retries = 0;
    bool success = false;

    while (retries <= MAX_RETRIES) {
        int bytesSent = sendto(clientSocket, &request, sizeof(request), 0, (struct sockaddr*)&serverAddr, sizeof(serverAddr));
        if (bytesSent == -1) {
            perror("Sendto failed");
            close(clientSocket);
            return 1;
        }

        struct calcProtocol response;
        socklen_t addrSize = sizeof(serverAddr);

        int bytesReceived = recvfrom(clientSocket, &response, sizeof(response), 0, (struct sockaddr*)&serverAddr, &addrSize);

        if (bytesReceived == -1) {
            retries++;
            if (retries <= MAX_RETRIES) {
                DEBUG_PRINT("Retransmitting...");
                alarm(TIMEOUT_SECONDS);
            } else {
                printf("Maximum number of retries reached. Terminating.\n");
                close(clientSocket);
                return 1;
            }
        } else {
            alarm(0);

            success = true;
            break;
        }
    }

    if (success) {
        if (debugEnabled) {
            printf("Host %s, and port %d.\n", SERVER_IP, SERVER_PORT);
            printf("ASSIGNMENT: add 1 2\n");
            printf("OK (myresult=...)\n");
        } else {
            printf("OK (myresult=...)\n");
        }
    } else {
        printf("Server sent a 'NOT OK' message. Terminating.\n");
    }

    close(clientSocket);
    return 0;
}


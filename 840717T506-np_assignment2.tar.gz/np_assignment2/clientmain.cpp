#include <stdio.h>
#include <stdlib.h>
/* You will to add includes here */


// Included to get the support library
#include <calcLib.h>


#include "protocol.h"

int main(int argc, char *argv[]){
  
  /* Do magic */

}
